<?php

$locale_arr = array (
    "template" => array (
        "T_en_gb" => "Inglese (UK)",
        "T_en_us" => "Inglese (Stati Uniti)",
        "T_fr_fr" => "Francese",
        "T_es_es" => "Spagnolo",
        "T_it_it" => "Italiano",
        "T_ar_ar" => "Arabo",
        "T_zh_cn" => "Cinese (semplificato)",
        "T_pt_br" => "Portoghese Brasiliano",
        ),
    );

?>
