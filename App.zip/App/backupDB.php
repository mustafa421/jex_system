<?php

	echo 'OOOOP not avaliable via this application'."\n";


?>
